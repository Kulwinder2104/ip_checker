# IP Checker

This Python package fetches the public IP address of your machine using an external service.

## Installation

To install the package from a source distribution, use:

```bash
pip install .
